package user;

public class Delete {
    private String userId = "e6217de5-551e-48bd-a372-9a260833d065";
    private String baseUrl = "https://demoqa.com/Account/v1/";
    private String token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyTmFtZSI6ImFsZGlkaTMiLCJwYXNzd29yZCI6IkFkbWluMTIzNCEiLCJpYXQiOjE2NDgyMjQxOTF9.WpvakOl3BrdVhMeWgnVxY1lmCRfOfkTxjkcQhhrCbgw";

}

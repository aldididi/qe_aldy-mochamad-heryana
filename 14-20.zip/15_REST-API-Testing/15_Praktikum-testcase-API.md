# Praktikum Membuat Test Cases REST API
> https://docs.google.com/spreadsheets/d/1UP52ABwf48wlkL-0dRLybdEqus_l5ybxyxaOqUYoZpY/edit#gid=0


# Manual to Automation
> https://docs.google.com/document/d/10hFGXRXGsM7I5jiB1JcsWrOoiP97_MdckpU72bir6Vo/edit
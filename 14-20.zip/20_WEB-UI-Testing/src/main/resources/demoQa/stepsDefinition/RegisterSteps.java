package demoQa.stepsDefinition;

public class RegisterSteps {
    @io.cucumber.java.en.Given("I am on the login page")
    public void iAmOnTheLoginPage() {
    }

    @io.cucumber.java.en.When("I click new user")
    public void iClickNewUser() {
    }

    @io.cucumber.java.en.And("I directed to register page")
    public void iDirectedToRegisterPage() {
    }

    @io.cucumber.java.en.And("I input first name")
    public void iInputFirstName() {
    }

    @io.cucumber.java.en.And("I input last name")
    public void iInputLastName() {
    }

    @io.cucumber.java.en.And("I input username regis")
    public void iInputUsernameRegis() {
    }

    @io.cucumber.java.en.And("I input password regis")
    public void iInputPasswordRegis() {
    }

    @io.cucumber.java.en.And("I click {string}")
    public void iClick(String arg0) {
    }

    @io.cucumber.java.en.And("I click register button")
    public void iClickRegisterButton() {
    }

    @io.cucumber.java.en.And("show alert message")
    public void showAlertMessage() {
    }

    @io.cucumber.java.en.Then("click ok successfull register")
    public void clickOkSuccessfullRegister() {
    }
}

# Report Praktikum BDD
> https://docs.google.com/document/d/1HVSzubtP5Tv4KkPnQbLMubAHTJv-2F9Ra0dvPH82OSo/edit
package linkedin.homePage;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SearchAndHomePageStep {
    @Given("I go to homepage")
    public void iGoToHomepage() {
        
    }

    @When("I click search bar")
    public void iClickSearchBar() {
        
    }

    @And("type a words")
    public void typeAWords() {
        
    }

    @Then("show some results")
    public void showSomeResults() {
    }

    @When("I click MyNetwork button")
    public void iClickMyNetworkButton() {
        
    }

    @Then("I directed to my network page")
    public void iDirectedToMyNetworkPage() {
    }
}

package linkedin.networkPage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class NetworkStep {
    @Given("I go to network page")
    public void iGoToNetworkPage() {
        
    }

    @When("I click accept invitation")
    public void iClickAcceptInvitation() {
        
    }

    @Then("I have a connection with inviter")
    public void iHaveAConnectionWithInviter() {
        
    }

    @When("I click ignore invitation")
    public void iClickIgnoreInvitation() {
        
    }

    @Then("I rejected an invitation")
    public void iRejectedAnInvitation() {
    }
}

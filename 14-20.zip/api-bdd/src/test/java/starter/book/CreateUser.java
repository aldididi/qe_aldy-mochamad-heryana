package starter.book;

public class CreateUser {
}
